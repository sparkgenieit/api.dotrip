import { CreateVehicleDto } from './create-vehicle.dto';
export class RegisterVehicleDto extends CreateVehicleDto {}
