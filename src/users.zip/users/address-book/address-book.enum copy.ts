// src/users/address-book/address-book.enum.ts

export enum AddressType {
  HOME   = 'HOME',
  OFFICE = 'OFFICE',
  OTHER  = 'OTHER',
}
