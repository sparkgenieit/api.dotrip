import { IsString, IsInt } from 'class-validator';
export class CreateVehicleDto {
  @IsString() registrationNumber: string;
  @IsString() model: string;
    @IsString() image: string;
  @IsInt() capacity: number;
}
